Note: 
There were some typos in the code for the uvm_utilities in the BOOK print COPY.
These were actually  fixed in the code. The wrong files got picked up.

Please examine the makefile for the various targets



